package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

import modelo.Main;

public class FrameCliente extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JPasswordField passwordField;
	private Main main = new Main();
	private JPasswordField passwordField_1;
	private JTextField NameField;
	private JTextField SaldoField;
		
	
	public FrameCliente() {
		setBounds(100, 100, 292, 221);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		this.setLocationRelativeTo(null);
		contentPanel.setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setBounds(10, 11, 70, 14);
		contentPanel.add(lblUsuario);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a");
		lblContrasea.setBounds(10, 34, 70, 14);
		contentPanel.add(lblContrasea);
		
		textField = new JTextField();
		textField.setBounds(90, 8, 120, 20);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(90, 31, 120, 20);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		getContentPane().setLayout(null);
		{
			JLabel lblUsuario_1 = new JLabel("Cuenta");
			lblUsuario_1.setBounds(10, 11, 70, 14);
			getContentPane().add(lblUsuario_1);
		}
		{
			JLabel lblContrasea_1 = new JLabel("Nombre");
			lblContrasea_1.setBounds(10, 36, 70, 14);
			getContentPane().add(lblContrasea_1);
		}
		{
			textField = new JTextField();
			textField.setBounds(81, 8, 154, 20);
			getContentPane().add(textField);
			textField.setColumns(10);
		}
		
		
		
		JLabel label = new JLabel("Saldo");
		label.setBounds(10, 61, 70, 14);
		getContentPane().add(label);
		
		
	
		{
			JButton cancelButton = new JButton("Cancelar");
			cancelButton.setBounds(136, 110, 99, 23);
			getContentPane().add(cancelButton);
			
			{
				JButton okButton = new JButton("Buscar");
				okButton.setBounds(37, 110, 89, 23);
				getContentPane().add(okButton);
				
				NameField = new JTextField();
				NameField.setColumns(10);
				NameField.setBounds(81, 33, 154, 20);
				getContentPane().add(NameField);
				
				SaldoField = new JTextField();
				SaldoField.setColumns(10);
				SaldoField.setBounds(81, 58, 154, 20);
				getContentPane().add(SaldoField);
				okButton.addActionListener(this);
				
				
			}
			cancelButton.addActionListener(this);
		}
	}


	@Override
	public void actionPerformed(ActionEvent arg) {
		
		String evento = arg.getActionCommand();
		if (evento.equals("Buscar")){
			BuscarCuenta();
		}
		else if (evento.equals("Cancelar")){
			System.exit(0);
		}
	}
	
private void BuscarCuenta() {
	
	
	String cuenta = textField.getText();
	
	String datos = main.BuscarCuenta(cuenta);
	String str[] = datos.split(",");        
    List<String> al = new ArrayList<String>();
    al = Arrays.asList(str);
    
    NameField.setText(al.get(0));
    SaldoField.setText(al.get(1));
    
		if (al.get(0).equals("Falso")){			
		JOptionPane.showMessageDialog(null, "Operaci�n Fallo");}
		else{JOptionPane.showMessageDialog(null, "Operaci�n Ok");}
	}
}

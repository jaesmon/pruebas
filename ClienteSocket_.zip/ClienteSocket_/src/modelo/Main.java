package modelo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.io.FileOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;


import gui.FrameCliente;


public class Main {
	
	static Socket sckt;
    static DataInputStream dtinpt;
    static DataOutputStream dtotpt;
	
	
public String BuscarCuenta(String cuenta) {                                                      
	      
		System.out
		.println("Buscar"+cuenta);
		 String msgin="";
		 String msgout="";
		try
	        {
	            msgout="1,"+cuenta;
	            dtotpt.writeUTF(msgout);
	            dtinpt = new DataInputStream(sckt.getInputStream());
	            msgin =  msgin =dtinpt.readUTF(); 
	        }
	        catch(Exception e)
	        {
	        }
return msgin;
	    } 
	
	public static void main(String[] args) {
		
		FrameCliente login = new FrameCliente();
  		login.setVisible(true);
		
		try
        {
            sckt = new Socket("127.0.0.1",1207);
            dtinpt = new DataInputStream(sckt.getInputStream());
            dtotpt = new DataOutputStream(sckt.getOutputStream());
            String msgin=""; 
        }
        catch(Exception e)
        {
        	
        }
	}
		

}

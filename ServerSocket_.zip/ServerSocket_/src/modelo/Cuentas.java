package modelo;

import java.io.Serializable;


public class Cuentas implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String cuenta;
	private String nombre;
	private int saldo;
	private int perfil;
		

	public Cuentas(String user, String nombre,int saldo) {
		this.cuenta = user;
		this.nombre = nombre;
		this.saldo = saldo;
		
	}
	
	public String getCuenta() {
		return cuenta;
	}
	
	public int getSaldo() {
		return saldo;
	}
public String ValidarCuenta(String a ) {
		String datos = "";
			if (cuenta.equals(a)){
				datos = nombre+","+saldo;
			}
		return datos;
}	
	
public String getData() {
	
		
		String data;
		data = this.nombre+","+this.saldo;
		
		return data;
	}
	
	
	
	public void SetUser(String cuenta,String nombre, int role) {
		this.cuenta = cuenta;
		this.nombre = nombre;
		this.saldo = role;
	}
	
	
}

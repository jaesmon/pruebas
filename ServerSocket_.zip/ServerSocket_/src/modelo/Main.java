package modelo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.FileOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import gui.FrameServer;


public class Main {
	
	private Properties properties;	
	public static ArrayList<Cuentas>cuentas;
	static ServerSocket ssckt;
	static Socket sckt;
    static DataInputStream dtinpt;
    static DataOutputStream dtotpt;
	
	
	public String BuscarCuenta(String cuenta) {                                                      
	      
		System.out
		.println("Buscar"+cuenta);
		 String msgin="";
		 String msgout="";
		try
	        {
	            msgout="4,"+cuenta;
	            dtotpt.writeUTF(msgout);
	            dtinpt = new DataInputStream(sckt.getInputStream());
	            msgin =  msgin =dtinpt.readUTF(); 
	            
	            //String str[] = msgin.split(",");        
	            //List<String> al = new ArrayList<String>();
	            //al = Arrays.asList(str);
	            
	            
	           // txt_nombrecliente6.setText(al.get(0));
	            //txt_apellidocliente6.setText(al.get(1));
	            //txt_dircliente6.setText(al.get(2));
	            //txt_ciudadcliente6.setText(al.get(3));
	            //txt_nrocuenta6.setText(al.get(4));
	            //txt_saldo6.setText(al.get(5));
	            //System.out.print(al.get(0));
	            return msgin;
	        }
	        catch(Exception e)
	        {
	        }
return msgin;
	    } 
	
	public static void main(String[] args) {
		
		FrameServer server = new FrameServer();
  		server.setVisible(true);
		        String msgin ="";
         try
         {
             
             ssckt = new ServerSocket(1207);
             System.out.println("Escuchando: " + ssckt);
             sckt = ssckt.accept();
             
             dtinpt = new DataInputStream(sckt.getInputStream());
             dtotpt = new DataOutputStream(sckt.getOutputStream());
             while(!msgin.equals("exit"))
             {            
                 msgin =dtinpt.readUTF();
                 
                 server.EstadoField.setText("\n Client:"+msgin);
                 String str[] = msgin.split(",");        
                 List<String> al = new ArrayList<String>();
                 al = Arrays.asList(str);
                 System.out.println(al.get(0));
                 String mesage = null;
                 switch (al.get(0).toString()) {
                         case "1":
                             mesage = getUserData(al.get(1));
                             dtotpt.writeUTF(mesage);
                         break;
                           
                 } 
                
             }
         }
         catch(Exception e)
         {
         }
			
		
	}
	
	public Main() {
			
		cargarParametrosDelSistema();
		cargarDatos();
						
				
	}
	
	private void crearBaseDeDatosInicial() {
		
		 // Se crea la base de datos inicial
		 		
		cuentas = new ArrayList<Cuentas>();					
		cuentas.add(new Cuentas("0001","Luz Adriana",2000));
		cuentas.add(new Cuentas("0002","Jorge Holgin",1000));
		cuentas.add(new Cuentas("0003","Javier Esteban",1000));
		cuentas.add(new Cuentas("0004","Andres Diaz",1000));
		cuentas.add(new Cuentas("0005","Marisol Gutierrez",1000));
		guardar();
	}
	
	private void cargarParametrosDelSistema() {
		// cargar parametros
		properties = new Properties();
		try (FileInputStream fis = new FileInputStream(
				"src/propiedades/Parametros")) {
			properties.load(fis);
		} catch (FileNotFoundException fnfe) {
			System.out
					.println("No se econtr� el archivo de par�metros del sistema");
			System.exit(0);
		} catch (IOException ioe) {
			System.out
					.println("Error al cargar el archivo de par�metros del sistema");
			System.exit(0);
		}
	}
	
	
	
	private void cargarDatos() {
		
		try (		
				
				
				ObjectInputStream oisCuentas = new ObjectInputStream(
						new FileInputStream(
								properties.getProperty("rutaCuentas")));	
				
				) {
			
			// Cargar informacion
			
			cuentas = (ArrayList<Cuentas>) oisCuentas.readObject();
			
		} catch (FileNotFoundException fne) {
			
			System.out
					.println("No se encontr� una base de datos existente, se proceder� a crear una base de datos inicial");
			crearBaseDeDatosInicial();
		} catch (IOException ioe) {
			
			ioe.printStackTrace();
			System.out
					.println("Ocurri� un error desconocido al leer la base de datos.");
			System.out
					.println("�Desea crear una nueva base de datos? (nota: se perder�n todos los datos salvados previamente)");
			System.out.print("Elija una opci�n [s/n]: ");

		String opcion = "s";

			switch (opcion) {
			case "s":
				System.out
						.println("Se proceder� a crear la base de datos inicial");
				crearBaseDeDatosInicial();
				break;
			case "n":
				System.out
						.println("Se cerrar� la aplicaci�n. Por favor contacte al administrador");
				System.exit(0);
				break;
			default:
				System.out
						.println("Se ha seleccionado una opci�n inv�lida. No se har�n cambios a la aplicaci�n. Adios");
				System.exit(0);
			}
		} catch (ClassNotFoundException cnfe) {
			
			System.out
					.println("Archivos de base de datos corruptos. La aplicaci�n se cerrar�.");
			System.exit(0);
		}
	}
	
	public void guardar() {
		try (			
				ObjectOutputStream ossCuenta = new ObjectOutputStream(
						new FileOutputStream(
								properties.getProperty("rutaCuentas")));
				
				) {					
		
			ossCuenta.writeObject(cuentas);
		
			System.out.println("Se guard� la informaci�n exitosamente");
		} 
		
		catch (IOException ioe) {
			System.out.println("Error al salvar los datos");
		}
				
	}

	









	




public static String getUserData(String a) {	
	
	String data = "Falso,0";
	
	for (Cuentas s: cuentas) {		 
		if (s.getCuenta().equals(a)){
			data = s.getData();
			
		}				
	}
	
	return data;	
		
}



	

















	
	

}

package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

import modelo.Main;

public class FrameServer extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPanel = new JPanel();
	private JTextField textField;
	public JTextField EstadoField;
	private JTextField textField_1;
	private JPasswordField passwordField;
	private Main main = new Main();
	private JPasswordField passwordField_1;
		
	
	public FrameServer() {
		setBounds(100, 100, 292, 221);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		this.setLocationRelativeTo(null);
		contentPanel.setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setBounds(10, 11, 70, 14);
		contentPanel.add(lblUsuario);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a");
		lblContrasea.setBounds(10, 34, 70, 14);
		contentPanel.add(lblContrasea);
		
		textField = new JTextField();
		textField.setBounds(90, 8, 120, 20);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(90, 31, 120, 20);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		getContentPane().setLayout(null);
		{
			JLabel lblUsuario_1 = new JLabel("Server Machine");
			lblUsuario_1.setBounds(91, 11, 114, 14);
			getContentPane().add(lblUsuario_1);
		}
		{
			EstadoField = new JTextField();
			EstadoField.setBounds(10, 28, 256, 110);
			getContentPane().add(EstadoField);
			EstadoField.setColumns(10);
		}
	}


	@Override
	public void actionPerformed(ActionEvent arg) {
		
		String evento = arg.getActionCommand();
		if (evento.equals("Buscar")){
			BuscarCuenta();
		}
		else if (evento.equals("Cancelar")){
			System.exit(0);
		}
	}
	
private void BuscarCuenta() {
	
	
	String cuenta = EstadoField.getText();
	
	String datos = main.BuscarCuenta(cuenta);
	String str[] = datos.split(",");        
    List<String> al = new ArrayList<String>();
    al = Arrays.asList(str);
    
    
	
		//if (perfil != 0){
			
			//DesktopPrincipal Desktop = new DesktopPrincipal(perfil);
			//Desktop.isActive();
			//dispose();
			
		////}
		//else{JOptionPane.showMessageDialog(null, "Usuario/Contrase�a Incorrecta");}
	}
}
